package com.sinodal.sinodalreport.controller;

import com.sinodal.sinodalreport.dto.LoginRequest;
import com.sinodal.sinodalreport.dto.LoginResponse;
import com.sinodal.sinodalreport.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/login")
    public LoginResponse login(@Valid @RequestBody LoginRequest request) {
        log.info("POST /api/auth/login");
        return authService.login(request);
    }
}