package com.sinodal.sinodalreport.dto;

public record LoginResponse(String mensagem, Long id, String nome, String tipo) {
}