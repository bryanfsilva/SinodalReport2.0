package com.sinodal.sinodalreport.controller;

import com.sinodal.sinodalreport.dto.RoleRequest;
import com.sinodal.sinodalreport.dto.RoleResponse;
import com.sinodal.sinodalreport.service.RoleService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/roles")
@RequiredArgsConstructor
public class RoleController {

    private final RoleService roleService;

    @GetMapping
    public List<RoleResponse> listar() {
        return roleService.listar();
    }

    @PostMapping
    public ResponseEntity<RoleResponse> criar(@Valid @RequestBody RoleRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(roleService.criar(request));
    }
}