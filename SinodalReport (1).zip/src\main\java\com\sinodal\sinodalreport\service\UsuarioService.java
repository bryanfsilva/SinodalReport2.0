package com.sinodal.sinodalreport.service;

import com.sinodal.sinodalreport.dto.UsuarioRequest;
import com.sinodal.sinodalreport.dto.UsuarioResponse;

import java.util.List;

public interface UsuarioService {

    List<UsuarioResponse> listar();

    UsuarioResponse buscar(Long id);

    UsuarioResponse criar(UsuarioRequest request);

    UsuarioResponse atualizar(Long id, UsuarioRequest request);

    void remover(Long id);

    UsuarioResponse atribuirRole(Long id, String nomeRole);
}