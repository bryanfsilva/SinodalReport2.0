package com.sinodal.sinodalreport.dto;

import com.sinodal.sinodalreport.model.Role;
import com.sinodal.sinodalreport.model.Usuario;

import java.util.List;

public record UsuarioResponse(
        Long id,
        String nome,
        String email,
        String login,
        String tipo,
        String perfil,
        boolean podeGerenciarUsuarios,
        List<String> roles
) {
    public static UsuarioResponse de(Usuario u) {
        return new UsuarioResponse(
                u.getId(),
                u.getNome(),
                u.getEmail(),
                u.getLogin(),
                u.getTipo(),
                u.descreverPerfil(),
                u.podeGerenciarUsuarios(),
                u.getRoles().stream().map(Role::getNome).toList()
        );
    }
}