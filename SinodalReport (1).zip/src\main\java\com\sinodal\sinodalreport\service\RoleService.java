package com.sinodal.sinodalreport.service;

import com.sinodal.sinodalreport.dto.RoleRequest;
import com.sinodal.sinodalreport.dto.RoleResponse;
import com.sinodal.sinodalreport.exception.RegraNegocioException;
import com.sinodal.sinodalreport.model.Role;
import com.sinodal.sinodalreport.repository.RoleRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class RoleService {

    private final RoleRepository roleRepository;

    public List<RoleResponse> listar() {
        return roleRepository.findAll().stream().map(RoleResponse::de).toList();
    }

    public RoleResponse criar(RoleRequest request) {
        if (roleRepository.existsByNome(request.nome())) {
            throw new RegraNegocioException("Role já existe: " + request.nome());
        }

        Role role = new Role();
        role.setNome(request.nome());
        role.setDescricao(request.descricao());

        Role salva = roleRepository.save(role);
        log.info("Role criada: {}", salva.getNome());
        return RoleResponse.de(salva);
    }
}