package com.sinodal.sinodalreport.exception;

public class RecursosNaoEncontradoException extends RuntimeException {

    public RecursosNaoEncontradoException(String mensagem) {
        super(mensagem);
    }
}