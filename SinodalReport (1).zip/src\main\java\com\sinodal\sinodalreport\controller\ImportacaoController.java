package com.sinodal.sinodalreport.controller;

import com.sinodal.sinodalreport.dto.ResumoImportacao;
import com.sinodal.sinodalreport.service.ImportacaoService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/api/usuarios/importar")
@RequiredArgsConstructor
public class ImportacaoController {

    private final ImportacaoService importacaoService;

    @PostMapping
    public ResumoImportacao importar() {
        log.info("POST /api/usuarios/importar");
        return importacaoService.importar();
    }
}