package com.sinodal.sinodalreport.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("ADMIN")
public class Administrador extends Usuario {

    @Override
    public String descreverPerfil() {
        return "Administrador: " + getNome();
    }

    @Override
    public boolean podeGerenciarUsuarios() {
        return true;
    }

    @Override
    public String getTipo() {
        return "ADMIN";
    }
}