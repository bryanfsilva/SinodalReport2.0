package com.sinodal.sinodalreport.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.HashSet;
import java.util.Set;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "tipo_usuario")
@Getter
@Setter
public abstract class Usuario extends Pessoa {

    @Column(nullable = false, unique = true)
    private String login;

    @Column(nullable = false)
    private String senha;

    @ManyToMany
    @JoinTable(
            name = "usuario_roles",
            joinColumns = @JoinColumn(name = "usuario_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id")
    )
    private Set<Role> roles = new HashSet<>();

    // Método 1
    public void adicionarRole(Role role) {
        roles.add(role);
    }

    // Método 2
    public void removerRole(Role role) {
        roles.remove(role);
    }

    // Método 3 (com sobrecarga: recebe String ou Role)
    public boolean possuiRole(String nomeRole) {
        return roles.stream().anyMatch(r -> r.getNome().equals(nomeRole));
    }

    public boolean possuiRole(Role role) {
        return roles.contains(role);
    }

    public abstract boolean podeGerenciarUsuarios();

    public abstract String getTipo();
}