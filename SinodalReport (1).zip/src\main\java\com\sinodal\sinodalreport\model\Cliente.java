package com.sinodal.sinodalreport.model;


import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("CLIENTE")
public class Cliente extends Usuario {

    @Override
    public String descreverPerfil() {
        return "Cliente: " + getNome();
    }

    @Override
    public boolean podeGerenciarUsuarios() {
        return false;
    }

    @Override
    public String getTipo() {
        return "CLIENTE";
    }
}