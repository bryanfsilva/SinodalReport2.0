package com.sinodal.sinodalreport.dto;

import jakarta.validation.constraints.NotBlank;

public record RoleRequest(
        @NotBlank String nome,
        String descricao
) {
}