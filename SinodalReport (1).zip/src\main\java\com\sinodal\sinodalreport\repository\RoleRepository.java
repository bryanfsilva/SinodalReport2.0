package com.sinodal.sinodalreport.repository;


import com.sinodal.sinodalreport.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RoleRepository extends JpaRepository<Role, Long> {

    Optional<Role> findByNome(String nome);

    boolean existsByNome(String nome);
}