package com.sinodal.sinodalreport.exception;

import com.sinodal.sinodalreport.dto.ErroResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(RecursosNaoEncontradoException.class)
    public ResponseEntity<ErroResponse> naoEncontrado(RecursosNaoEncontradoException e) {
        log.warn("Não encontrado: {}", e.getMessage());
        return montar(HttpStatus.NOT_FOUND, e.getMessage());
    }

    @ExceptionHandler(RegraNegocioException.class)
    public ResponseEntity<ErroResponse> regraNegocio(RegraNegocioException e) {
        log.warn("Regra de negócio: {}", e.getMessage());
        return montar(HttpStatus.CONFLICT, e.getMessage());
    }

    @ExceptionHandler(CredenciaisInvalidasException.class)
    public ResponseEntity<ErroResponse> credenciais(CredenciaisInvalidasException e) {
        log.warn("Login inválido: {}", e.getMessage());
        return montar(HttpStatus.UNAUTHORIZED, e.getMessage());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErroResponse> validacao(MethodArgumentNotValidException e) {
        String mensagem = e.getBindingResult().getFieldErrors().stream()
                .map(erro -> erro.getField() + ": " + erro.getDefaultMessage())
                .findFirst()
                .orElse("Dados inválidos");
        log.warn("Validação: {}", mensagem);
        return montar(HttpStatus.BAD_REQUEST, mensagem);
    }

    @ExceptionHandler(org.springframework.http.converter.HttpMessageNotReadableException.class)
    public ResponseEntity<ErroResponse> jsonInvalido(Exception e) {
        log.warn("JSON inválido: {}", e.getMessage());
        return montar(HttpStatus.BAD_REQUEST, "JSON inválido ou mal formatado");
    }

    @ExceptionHandler(org.springframework.web.servlet.resource.NoResourceFoundException.class)
    public ResponseEntity<ErroResponse> semRecurso(Exception e) {
        return montar(HttpStatus.NOT_FOUND, "Endereço não encontrado");
    }

    @ExceptionHandler(org.springframework.web.HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ErroResponse> metodoNaoSuportado(Exception e) {
        return montar(HttpStatus.METHOD_NOT_ALLOWED, "Método HTTP não permitido para este endereço");
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErroResponse> generico(Exception e) {
        log.error("Erro inesperado", e);
        return montar(HttpStatus.INTERNAL_SERVER_ERROR, "Erro interno no servidor");
    }

    private ResponseEntity<ErroResponse> montar(HttpStatus status, String mensagem) {
        ErroResponse corpo = new ErroResponse(
                status.value(), status.getReasonPhrase(), mensagem, LocalDateTime.now());
        return ResponseEntity.status(status).body(corpo);
    }
}