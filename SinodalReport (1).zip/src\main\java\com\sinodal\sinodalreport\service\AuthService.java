package com.sinodal.sinodalreport.service;

import com.sinodal.sinodalreport.dto.LoginRequest;
import com.sinodal.sinodalreport.dto.LoginResponse;
import com.sinodal.sinodalreport.exception.CredenciaisInvalidasException;
import com.sinodal.sinodalreport.model.RegistroAcesso;
import com.sinodal.sinodalreport.model.Usuario;
import com.sinodal.sinodalreport.repository.RegistroAcessoRepository;
import com.sinodal.sinodalreport.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final UsuarioRepository usuarioRepository;
    private final RegistroAcessoRepository registroAcessoRepository;
    private final PasswordEncoder passwordEncoder;

    public LoginResponse login(LoginRequest request) {
        Optional<Usuario> encontrado = usuarioRepository.findByLogin(request.login());

        boolean ok = encontrado.isPresent()
                && passwordEncoder.matches(request.senha(), encontrado.get().getSenha());

        RegistroAcesso registro = new RegistroAcesso();
        registro.setLoginTentado(request.login());
        registro.setSucesso(ok);
        registro.setUsuario(encontrado.orElse(null));
        registroAcessoRepository.save(registro);

        if (!ok) {
            log.warn("Login falhou para: {}", request.login());
            throw new CredenciaisInvalidasException("Login ou senha inválidos");
        }

        Usuario usuario = encontrado.get();
        log.info("Login ok: {}", usuario.getLogin());
        return new LoginResponse("Login realizado com sucesso", usuario.getId(),
                usuario.getNome(), usuario.getTipo());
    }
}