package com.sinodal.sinodalreport.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
public class RegistroAcesso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Usuario usuario; // pode ser nulo se o login não existir

    private String loginTentado;

    private boolean sucesso;

    private LocalDateTime dataHora = LocalDateTime.now();
}