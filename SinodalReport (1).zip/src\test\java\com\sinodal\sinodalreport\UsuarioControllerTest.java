package com.sinodal.sinodalreport;

import com.sinodal.sinodalreport.controller.UsuarioController;
import com.sinodal.sinodalreport.exception.GlobalExceptionHandler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

@SpringBootTest
@Transactional
class UsuarioControllerTest {

    @Autowired
    private UsuarioController usuarioController;

    private MockMvc mockMvc;

    @BeforeEach
    void preparar() {
        mockMvc = MockMvcBuilders.standaloneSetup(usuarioController)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    private MvcResult enviar(String json) throws Exception {
        return mockMvc.perform(post("/api/usuarios")
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)).andReturn();
    }

    @Test
    void jsonValidoRetorna201SemSenha() throws Exception {
        MvcResult r = enviar("""
                {"nome":"Carla","email":"carla@escola.com","login":"carla",
                 "senha":"senha123","tipo":"CLIENTE","roles":["ROLE_USER"]}
                """);

        assertEquals(201, r.getResponse().getStatus());
        assertFalse(r.getResponse().getContentAsString().contains("\"senha\""));
    }

    @Test
    void jsonSemLoginRetorna400() throws Exception {
        MvcResult r = enviar("""
                {"nome":"Carla","email":"carla@escola.com",
                 "senha":"senha123","tipo":"CLIENTE"}
                """);

        assertEquals(400, r.getResponse().getStatus());
    }

    @Test
    void jsonMalFormadoRetorna400() throws Exception {
        MvcResult r = enviar("{isso nao e json");

        assertEquals(400, r.getResponse().getStatus());
    }

    @Test
    void loginRepetidoRetorna409() throws Exception {
        String json = """
                {"nome":"Dora","email":"dora@escola.com","login":"dora",
                 "senha":"senha123","tipo":"CLIENTE"}
                """;
        enviar(json);

        assertEquals(409, enviar(json).getResponse().getStatus());
    }
}