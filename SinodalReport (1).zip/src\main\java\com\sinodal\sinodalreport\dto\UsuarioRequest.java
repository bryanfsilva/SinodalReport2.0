package com.sinodal.sinodalreport.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.util.List;

public record UsuarioRequest(
        @NotBlank String nome,
        @NotBlank @Email String email,
        @NotBlank String login,
        @NotBlank @Size(min = 6) String senha,
        @NotBlank @Pattern(regexp = "ADMIN|CLIENTE") String tipo,
        List<String> roles
) {
}