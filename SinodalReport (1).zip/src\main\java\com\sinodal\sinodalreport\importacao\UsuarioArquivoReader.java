package com.sinodal.sinodalreport.importacao;

import com.sinodal.sinodalreport.dto.FalhaLinha;
import com.sinodal.sinodalreport.dto.UsuarioRequest;
import com.sinodal.sinodalreport.exception.RecursosNaoEncontradoException;
import com.sinodal.sinodalreport.exception.RegraNegocioException;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

@Slf4j
@Component
@RequiredArgsConstructor
public class UsuarioArquivoReader {

    private final Validator validator;

    public ResultadoLeitura ler(Path caminho) {
        // Erros do arquivo inteiro
        if (!Files.exists(caminho)) {
            log.warn("Arquivo não encontrado: {}", caminho);
            throw new RecursosNaoEncontradoException("Arquivo não encontrado: " + caminho);
        }
        if (!Files.isReadable(caminho)) {
            log.warn("Sem permissão de leitura: {}", caminho);
            throw new RegraNegocioException("Sem permissão para ler o arquivo: " + caminho);
        }

        List<LinhaArquivo> validas = new ArrayList<>();
        List<FalhaLinha> falhas = new ArrayList<>();
        int lidas = 0;
        int numero = 0;

        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(Files.newInputStream(caminho), StandardCharsets.UTF_8))) {

            String linha;
            while ((linha = br.readLine()) != null) {
                numero++;
                String texto = linha.trim();

                // Ignora linha vazia, comentário e cabeçalho
                if (texto.isEmpty() || texto.startsWith("#")
                        || texto.toLowerCase().startsWith("tipo;login")) {
                    continue;
                }

                lidas++;
                try {
                    validas.add(new LinhaArquivo(numero, converter(numero, texto)));
                } catch (IllegalArgumentException e) {
                    // Erro só desta linha: registra e continua
                    log.warn("linha {} ignorada: {}", numero, e.getMessage());
                    falhas.add(new FalhaLinha(numero, e.getMessage()));
                }
            }
        } catch (IOException e) {
            log.error("Falha de I/O ao ler o arquivo {}", caminho, e);
            throw new UncheckedIOException(e);
        }

        return new ResultadoLeitura(lidas, validas, falhas);
    }

    private UsuarioRequest converter(int numero, String texto) {
        String[] c = texto.split(";", -1);
        if (c.length != 6) {
            throw new IllegalArgumentException(
                    "linha malformada: esperado 6 campos, encontrado " + c.length);
        }

        log.debug("lendo linha {}: login={}", numero, c[1].trim());

        String tipo = c[0].trim().toUpperCase();
        if (!tipo.equals("ADMIN") && !tipo.equals("CLIENTE")) {
            throw new IllegalArgumentException("tipo inválido: " + c[0].trim());
        }

        List<String> roles = c[5].isBlank()
                ? List.of()
                : Arrays.stream(c[5].split(",")).map(String::trim).filter(s -> !s.isEmpty()).toList();

        UsuarioRequest request = new UsuarioRequest(
                c[2].trim(), c[3].trim(), c[1].trim(), c[4].trim(), tipo, roles);

        // Mesmas regras do JSON (campo vazio, e-mail inválido, senha curta)
        Set<ConstraintViolation<UsuarioRequest>> erros = validator.validate(request);
        if (!erros.isEmpty()) {
            ConstraintViolation<UsuarioRequest> primeiro = erros.iterator().next();
            throw new IllegalArgumentException(primeiro.getPropertyPath() + ": " + primeiro.getMessage());
        }
        return request;
    }
}