package com.sinodal.sinodalreport.importacao;

import com.sinodal.sinodalreport.dto.FalhaLinha;

import java.util.List;

public record ResultadoLeitura(int linhasLidas, List<LinhaArquivo> validas, List<FalhaLinha> falhas) {
}