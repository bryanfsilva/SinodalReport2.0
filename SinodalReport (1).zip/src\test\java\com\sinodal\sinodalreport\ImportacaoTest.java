package com.sinodal.sinodalreport;

import com.sinodal.sinodalreport.dto.ResumoImportacao;
import com.sinodal.sinodalreport.exception.RecursosNaoEncontradoException;
import com.sinodal.sinodalreport.service.ImportacaoService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
class ImportacaoTest {

    @Autowired
    private ImportacaoService importacaoService;

    @TempDir
    Path pasta;

    @Test
    void umaLinhaBoaEDuasRuins() throws IOException {
        Path arquivo = pasta.resolve("usuarios.txt");
        Files.writeString(arquivo, String.join("\n",
                "CLIENTE;teste1;Teste Um;teste1@escola.com;senha123;ROLE_USER",
                "VISITANTE;teste2;Teste Dois;teste2@escola.com;senha123;ROLE_USER",
                "CLIENTE;admin;Outro;outro@escola.com;senha123;ROLE_USER"));

        ResumoImportacao resumo = importacaoService.importar(arquivo);

        assertEquals(3, resumo.linhasLidas());
        assertEquals(1, resumo.gravadas());
        assertEquals(2, resumo.falhas().size());
        assertEquals(2, resumo.falhas().get(0).linha());   // tipo inválido
        assertEquals(3, resumo.falhas().get(1).linha());   // login repetido
    }

    @Test
    void ignoraLinhaVaziaEComentario() throws IOException {
        Path arquivo = pasta.resolve("usuarios.txt");
        Files.writeString(arquivo, String.join("\n",
                "# comentário",
                "",
                "CLIENTE;teste3;Teste Tres;teste3@escola.com;senha123;ROLE_USER"));

        ResumoImportacao resumo = importacaoService.importar(arquivo);

        assertEquals(1, resumo.linhasLidas());
        assertEquals(1, resumo.gravadas());
        assertTrue(resumo.falhas().isEmpty());
    }

    @Test
    void arquivoInexistenteDaErroDoArquivoInteiro() {
        Path inexistente = pasta.resolve("nao-existe.txt");

        assertThrows(RecursosNaoEncontradoException.class,
                () -> importacaoService.importar(inexistente));
    }
}