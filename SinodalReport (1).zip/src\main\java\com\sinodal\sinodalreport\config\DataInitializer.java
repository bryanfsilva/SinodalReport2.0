package com.sinodal.sinodalreport.config;

import com.sinodal.sinodalreport.model.Administrador;
import com.sinodal.sinodalreport.model.Role;
import com.sinodal.sinodalreport.repository.RoleRepository;
import com.sinodal.sinodalreport.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UsuarioRepository usuarioRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        Role roleAdmin = garantirRole("ROLE_ADMIN", "Acesso de administrador");
        garantirRole("ROLE_USER", "Acesso de usuário comum");

        if (!usuarioRepository.existsByLogin("admin")) {
            Administrador admin = new Administrador();
            admin.setNome("Administrador");
            admin.setEmail("admin@sinodal.com");
            admin.setLogin("admin");
            admin.setSenha(passwordEncoder.encode("admin123"));
            admin.adicionarRole(roleAdmin);
            usuarioRepository.save(admin);
            log.info("Usuário admin criado (login: admin, senha: admin123)");
        }
    }

    private Role garantirRole(String nome, String descricao) {
        return roleRepository.findByNome(nome).orElseGet(() -> {
            Role r = new Role();
            r.setNome(nome);
            r.setDescricao(descricao);
            return roleRepository.save(r);
        });
    }
}