package com.sinodal.sinodalreport.dto;

import java.util.List;

public record ResumoImportacao(int linhasLidas, int gravadas, List<FalhaLinha> falhas) {
}