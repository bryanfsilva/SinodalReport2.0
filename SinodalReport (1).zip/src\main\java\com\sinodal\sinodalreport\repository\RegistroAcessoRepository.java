package com.sinodal.sinodalreport.repository;

import com.sinodal.sinodalreport.model.RegistroAcesso;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RegistroAcessoRepository extends JpaRepository<RegistroAcesso, Long> {
}