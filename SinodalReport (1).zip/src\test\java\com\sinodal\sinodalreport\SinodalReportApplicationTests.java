package com.sinodal.sinodalreport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SinodalReportApplicationTests {

    @Test
    void contextLoads() {
    }

}
