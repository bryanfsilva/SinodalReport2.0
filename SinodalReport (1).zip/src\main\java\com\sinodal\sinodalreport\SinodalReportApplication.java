package com.sinodal.sinodalreport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SinodalReportApplication {

    public static void main(String[] args) {
        SpringApplication.run(SinodalReportApplication.class, args);
    }

}
