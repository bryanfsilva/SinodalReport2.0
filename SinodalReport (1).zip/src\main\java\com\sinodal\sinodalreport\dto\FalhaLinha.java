package com.sinodal.sinodalreport.dto;

public record FalhaLinha(int linha, String motivo) {
}