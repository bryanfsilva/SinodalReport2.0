package com.sinodal.sinodalreport.importacao;

import com.sinodal.sinodalreport.dto.UsuarioRequest;

public record LinhaArquivo(int numero, UsuarioRequest request) {
}