package com.sinodal.sinodalreport.service;

import com.sinodal.sinodalreport.dto.FalhaLinha;
import com.sinodal.sinodalreport.dto.ResumoImportacao;
import com.sinodal.sinodalreport.exception.RegraNegocioException;
import com.sinodal.sinodalreport.importacao.LinhaArquivo;
import com.sinodal.sinodalreport.importacao.ResultadoLeitura;
import com.sinodal.sinodalreport.importacao.UsuarioArquivoReader;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class ImportacaoService {

    private final UsuarioArquivoReader reader;
    private final UsuarioService usuarioService;

    @Value("${app.usuarios.arquivo:usuarios.txt}")
    private String caminhoConfigurado;

    // Usa o caminho que está no application.properties
    public ResumoImportacao importar() {
        return importar(Path.of(caminhoConfigurado));
    }

    // Usado também nos testes, com um arquivo temporário
    public ResumoImportacao importar(Path caminho) {
        log.debug("Importando usuários de {}", caminho);
        ResultadoLeitura leitura = reader.ler(caminho);

        List<FalhaLinha> falhas = new ArrayList<>(leitura.falhas());
        int gravadas = 0;

        for (LinhaArquivo linha : leitura.validas()) {
            try {
                usuarioService.criar(linha.request());   // MESMO método do JSON
                gravadas++;
            } catch (RegraNegocioException e) {
                // login repetido, role inexistente... só esta linha falha
                log.warn("linha {} ignorada: {}", linha.numero(), e.getMessage());
                falhas.add(new FalhaLinha(linha.numero(), e.getMessage()));
            }
        }

        falhas.sort(Comparator.comparingInt(FalhaLinha::linha));
        return new ResumoImportacao(leitura.linhasLidas(), gravadas, falhas);
    }
}