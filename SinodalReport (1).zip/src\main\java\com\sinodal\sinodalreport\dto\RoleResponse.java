package com.sinodal.sinodalreport.dto;

import com.sinodal.sinodalreport.model.Role;

public record RoleResponse(Long id, String nome, String descricao) {

    public static RoleResponse de(Role r) {
        return new RoleResponse(r.getId(), r.getNome(), r.getDescricao());
    }
}