package com.sinodal.sinodalreport.service;

import com.sinodal.sinodalreport.dto.UsuarioRequest;
import com.sinodal.sinodalreport.dto.UsuarioResponse;
import com.sinodal.sinodalreport.exception.RecursosNaoEncontradoException;
import com.sinodal.sinodalreport.exception.RegraNegocioException;
import com.sinodal.sinodalreport.model.Administrador;
import com.sinodal.sinodalreport.model.Cliente;
import com.sinodal.sinodalreport.model.Role;
import com.sinodal.sinodalreport.model.Usuario;
import com.sinodal.sinodalreport.repository.RoleRepository;
import com.sinodal.sinodalreport.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class UsuarioServiceImpl implements UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public List<UsuarioResponse> listar() {
        log.debug("Listando usuários");
        List<Usuario> usuarios = usuarioRepository.findAll();
        return usuarios.stream().map(UsuarioResponse::de).toList();
    }

    @Override
    public UsuarioResponse buscar(Long id) {
        return UsuarioResponse.de(buscarEntidade(id));
    }

    @Override
    public UsuarioResponse criar(UsuarioRequest request) {
        if (usuarioRepository.existsByLogin(request.login())) {
            throw new RegraNegocioException("Login já existe: " + request.login());
        }

        Usuario usuario;
        if (request.tipo().equals("ADMIN")) {
            usuario = new Administrador();
        } else {
            usuario = new Cliente();
        }

        usuario.setNome(request.nome());
        usuario.setEmail(request.email());
        usuario.setLogin(request.login());
        usuario.setSenha(passwordEncoder.encode(request.senha()));

        if (request.roles() != null) {
            for (String nomeRole : request.roles()) {
                Role role = roleRepository.findByNome(nomeRole)
                        .orElseThrow(() -> new RegraNegocioException("Role não encontrada: " + nomeRole));
                usuario.adicionarRole(role);
            }
        }

        try {
            Usuario salvo = usuarioRepository.saveAndFlush(usuario);
            log.info("Usuário criado: {}", salvo.getLogin());
            return UsuarioResponse.de(salvo);
        } catch (DataIntegrityViolationException e) {
            log.error("Erro ao criar usuário", e);
            throw new RegraNegocioException("Não foi possível criar o usuário");
        }
    }

    @Override
    public UsuarioResponse atualizar(Long id, UsuarioRequest request) {
        Usuario usuario = buscarEntidade(id);

        boolean trocouLogin = !usuario.getLogin().equals(request.login());
        if (trocouLogin && usuarioRepository.existsByLogin(request.login())) {
            throw new RegraNegocioException("Login já existe: " + request.login());
        }

        usuario.setNome(request.nome());
        usuario.setEmail(request.email());
        usuario.setLogin(request.login());
        usuario.setSenha(passwordEncoder.encode(request.senha()));

        try {
            Usuario salvo = usuarioRepository.saveAndFlush(usuario);
            log.info("Usuário atualizado: {}", salvo.getLogin());
            return UsuarioResponse.de(salvo);
        } catch (DataIntegrityViolationException e) {
            log.error("Erro ao atualizar usuário", e);
            throw new RegraNegocioException("Não foi possível atualizar o usuário");
        }
    }

    @Override
    public void remover(Long id) {
        Usuario usuario = buscarEntidade(id);
        try {
            usuarioRepository.delete(usuario);
            usuarioRepository.flush();
            log.info("Usuário removido: {}", usuario.getLogin());
        } catch (DataIntegrityViolationException e) {
            log.error("Erro ao remover usuário", e);
            throw new RegraNegocioException("Não foi possível remover o usuário");
        }
    }

    @Override
    public UsuarioResponse atribuirRole(Long id, String nomeRole) {
        Usuario usuario = buscarEntidade(id);
        Role role = roleRepository.findByNome(nomeRole)
                .orElseThrow(() -> new RecursosNaoEncontradoException("Role não encontrada: " + nomeRole));

        usuario.adicionarRole(role);
        log.info("Role {} atribuída ao usuário {}", nomeRole, usuario.getLogin());
        return UsuarioResponse.de(usuarioRepository.save(usuario));
    }

    private Usuario buscarEntidade(Long id) {
        return usuarioRepository.findById(id)
                .orElseThrow(() -> new RecursosNaoEncontradoException("Usuário não encontrado: " + id));
    }
}